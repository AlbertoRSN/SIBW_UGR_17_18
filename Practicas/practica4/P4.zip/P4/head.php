	<head>
		<title>Museo del Automovil</title> <!-- nombre de la pestaña -->
		<meta charset="utf-8" />
		<meta name="Author" content="ARS">
		<meta name="Description" content="Practica 3 SIBW">
		<link rel="stylesheet" href="css/style4.css"> <!-- Enlazar archivo css -->

		<script src="javascript/javascript.js"></script>  <!-- Enlazar archivo javascript -->
	</head>