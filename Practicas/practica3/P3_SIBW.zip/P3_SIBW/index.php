<!-- Controlador -->
<html>
	<body>
		<?php include('header.php');
		?>
		<h1> Pagina de obra </h1>
		<p> Hola </p>
	</body>
</html>