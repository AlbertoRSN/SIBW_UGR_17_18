<!-- Plantilla Obra -->

<html>
	<body>
		<?php include('header.php');
		?>
		<h1> Pagina de obre </h1>
		<p> Hola </p>
	</body>
</html>