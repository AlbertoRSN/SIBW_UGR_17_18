<?php
	//include('head.php');
	//include('header.php');
	include ('BD/connection.php');
	//include('sidebar.php');
	include('Controladores/controlador_contenido.php');
	//include('footer.php');
?>

