<html>
<head>
<title>Título</title>
<input type=text size=50 name="nombre">
<?php
// Incluir bibliotecas de funciones
$nombre=$_GET['nombre'];
?>
</head>
<body>
<?php
include("cabecera.html");
?>
// Código HTML y PHP
. . .
<?php
include("pie.html");
?>
</body>
</html>