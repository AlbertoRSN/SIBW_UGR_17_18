

<footer><!-- PIE DE PAGINA -->
        <!--<input type="button" value="Imprime esta pagina" onclick="window.print()">-->
        <p>&copyMuseo del automovil</p>
        <p>Calle Periodista Daniel Saucedo Aranda, s/n • 18071 Granada </p>
        <p>958 24 28 02 • e-mail: ars@correo.ugr.es</p>
        <p><img id="footLogo" src="imagenes/footer.png"></p>
 
    </footer>