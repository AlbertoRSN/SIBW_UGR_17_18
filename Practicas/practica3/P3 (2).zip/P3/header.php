

	<header>
		<!-- LOGO CABECERA-->
		<div id="cabecera">
			<img id="logo-cab" src="imgs/logo10.png">
			<a href="portada3.html"><img id="titulo-cab" src="imgs/logonuevo2.png"></a>
		</div>

		<nav id="menu-cab">
			<a href="#">Inicio</a> 
			<a href="#">Sobre Nosotros</a>
			<a href="#">Contacto</a> 
		</nav><!-- / nav -->

	</header>