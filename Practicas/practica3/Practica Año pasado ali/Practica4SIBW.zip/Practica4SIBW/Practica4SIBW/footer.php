<footer id="foot">
				<p> Teléfono: +34 958 215 273 </p>
				<p> Fax: +34 958 225 765</p>	
				<p> Email: info@diario.com </p>
				<p> Dirección: C/Imprenta, n&deg; 2. 18010 Granada, Granada, España </p>
				<div id="disenadores">	
					<p> Design by: Sergio Bracho / Alicia Rodríguez</p>
				</div>
</footer>